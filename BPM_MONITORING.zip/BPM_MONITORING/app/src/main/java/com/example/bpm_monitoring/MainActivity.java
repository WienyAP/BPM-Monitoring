package com.example.bpm_monitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    TextView nilaiSensor, Status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //inisialisasi komponen
        nilaiSensor = (TextView)findViewById(R.id.nilaiSensor);
        Status = (TextView)findViewById(R.id.Status);

        //koneksi database
        DatabaseReference koneksi = FirebaseDatabase.getInstance().getReference();

        //baca isi database berdasarkan koneksi
        koneksi.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //Tampilkan nilai sensor di dalam aplikasi
                //baca nilai sensor
                String sensor = snapshot.child("Sensor").getValue().toString();
                nilaiSensor.setText(sensor);

                //uji nilai sensor untuk menentukan status
                if (sensor.equals("No Finger"))
                    Status.setText("Status: -");
                else if (Integer.parseInt(sensor) >= 60 && Integer.parseInt(sensor) <= 100)
                    Status.setText("Status: Normal");
                else
                    Status.setText("Staus: Tidak Normal");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}